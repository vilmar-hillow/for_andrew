import dotenv


def main():
    print(dotenv)
